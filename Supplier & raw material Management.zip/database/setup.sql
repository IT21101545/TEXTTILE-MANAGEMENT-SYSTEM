-- Run in SSMS with Windows Authentication
-- Only run this if TextileManagementSystem DB doesn't exist yet

USE TextileManagementSystem;
GO

-- Create login & user (run once)
-- CREATE LOGIN textlite_user WITH PASSWORD = 'Textlite@2026';
-- CREATE USER textlite_user FOR LOGIN textlite_user;
-- ALTER ROLE db_owner ADD MEMBER textlite_user;

-- Sample data (only if tables are empty)
INSERT INTO Suppliers (SupplierName, Phone, Email, Address) VALUES
('Fabric World Ltd',    '0711234567', 'fabric@world.lk',  'Colombo 03'),
('Thread Masters',      '0722345678', 'thread@master.lk', 'Kandy'),
('Dye Solutions Lanka', '0733456789', 'dye@sol.lk',       'Gampaha');

INSERT INTO RawMaterials (MaterialName, StockQuantity, Unit, UnitPrice, SupplierID) VALUES
('Cotton Fabric',    500, 'Meters', 250.00, 1),
('Polyester Fabric', 300, 'Meters', 180.00, 1),
('White Thread',     100, 'Rolls',   45.00, 2),
('Blue Dye',          15, 'Liters', 320.00, 3);

INSERT INTO RawMaterialPurchases (Notes, PurchaseDate, Quantity, TotalAmount, MaterialID, SupplierID) VALUES
('First batch',  '2026-03-01', 200, 50000.00, 1, 1),
('Thread stock', '2026-03-10',  50,  2250.00, 3, 2),
('Dye order',    '2026-03-20',  10,  3200.00, 4, 3);

USE master;
GO

-- Give textlite_user access to TextileManagementSystem
USE TextileManagementSystem;
GO

-- If user doesn't exist yet in this DB:
CREATE USER textlite_user FOR LOGIN textlite_user;
GO

ALTER ROLE db_owner ADD MEMBER textlite_user;
GO

USE TextileManagementSystem;
GO
ALTER ROLE db_owner ADD MEMBER textlite_user;
GO

USE TextileManagementSystem;
SELECT * FROM Suppliers;

SELECT * FROM RawMaterials;

SELECT * FROM RawMaterialPurchases;

