package com.textlite.dao;

import com.textlite.db.DBConnection;
import com.textlite.model.RawMaterialPurchase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RawMaterialPurchaseDAO {

    private RawMaterialDAO matDAO = new RawMaterialDAO();

    public boolean addPurchase(RawMaterialPurchase p) {
        String sql = "INSERT INTO RawMaterialPurchases (Notes, PurchaseDate, Quantity, TotalAmount, MaterialID, SupplierID) VALUES (?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, p.getNotes());
                ps.setDate(2, new java.sql.Date(p.getPurchaseDate().getTime()));
                ps.setDouble(3, p.getQuantity());
                ps.setDouble(4, p.getTotalAmount());
                ps.setInt(5, p.getMaterialID());
                ps.setInt(6, p.getSupplierID());
                ps.executeUpdate();
                // Update stock in RawMaterials
                matDAO.updateStock(con, p.getMaterialID(), p.getQuantity());
                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                e.printStackTrace();
                return false;
            }
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean updatePurchase(RawMaterialPurchase p) {
        String sql = "UPDATE RawMaterialPurchases SET Notes=?, PurchaseDate=?, Quantity=?, TotalAmount=?, MaterialID=?, SupplierID=? WHERE PurchaseID=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNotes());
            ps.setDate(2, new java.sql.Date(p.getPurchaseDate().getTime()));
            ps.setDouble(3, p.getQuantity());
            ps.setDouble(4, p.getTotalAmount());
            ps.setInt(5, p.getMaterialID());
            ps.setInt(6, p.getSupplierID());
            ps.setInt(7, p.getPurchaseID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean deletePurchase(int id) {
        String sql = "DELETE FROM RawMaterialPurchases WHERE PurchaseID=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public List<RawMaterialPurchase> getAllPurchases() {
        List<RawMaterialPurchase> list = new ArrayList<>();
        String sql = "SELECT rp.*, s.SupplierName, rm.MaterialName, rm.Unit " +
                     "FROM RawMaterialPurchases rp " +
                     "LEFT JOIN Suppliers s ON rp.SupplierID = s.SupplierID " +
                     "LEFT JOIN RawMaterials rm ON rp.MaterialID = rm.MaterialID " +
                     "ORDER BY rp.PurchaseID ASC";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<RawMaterialPurchase> searchPurchases(String kw) {
        List<RawMaterialPurchase> list = new ArrayList<>();
        String sql = "SELECT rp.*, s.SupplierName, rm.MaterialName, rm.Unit " +
                     "FROM RawMaterialPurchases rp " +
                     "LEFT JOIN Suppliers s ON rp.SupplierID = s.SupplierID " +
                     "LEFT JOIN RawMaterials rm ON rp.MaterialID = rm.MaterialID " +
                     "WHERE s.SupplierName LIKE ? OR rm.MaterialName LIKE ? OR rp.Notes LIKE ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String w = "%" + kw + "%";
            ps.setString(1, w); ps.setString(2, w); ps.setString(3, w);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    private RawMaterialPurchase map(ResultSet rs) throws SQLException {
        return new RawMaterialPurchase(
            rs.getInt("PurchaseID"),
            rs.getString("Notes"),
            rs.getDate("PurchaseDate"),
            rs.getDouble("Quantity"),
            rs.getDouble("TotalAmount"),
            rs.getInt("MaterialID"),
            rs.getInt("SupplierID"),
            rs.getString("MaterialName"),
            rs.getString("SupplierName"),
            rs.getString("Unit")
        );
    }
}
