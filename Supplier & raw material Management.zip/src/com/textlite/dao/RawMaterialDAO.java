package com.textlite.dao;

import com.textlite.db.DBConnection;
import com.textlite.model.RawMaterial;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RawMaterialDAO {

    public boolean addMaterial(RawMaterial m) {
        String sql = "INSERT INTO RawMaterials (MaterialName, StockQuantity, Unit, UnitPrice, SupplierID) VALUES (?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getMaterialName());
            ps.setDouble(2, m.getStockQuantity());
            ps.setString(3, m.getUnit());
            ps.setDouble(4, m.getUnitPrice());
            ps.setInt(5, m.getSupplierID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean updateMaterial(RawMaterial m) {
        String sql = "UPDATE RawMaterials SET MaterialName=?, StockQuantity=?, Unit=?, UnitPrice=?, SupplierID=? WHERE MaterialID=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getMaterialName());
            ps.setDouble(2, m.getStockQuantity());
            ps.setString(3, m.getUnit());
            ps.setDouble(4, m.getUnitPrice());
            ps.setInt(5, m.getSupplierID());
            ps.setInt(6, m.getMaterialID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean deleteMaterial(int id) {
        String sql = "DELETE FROM RawMaterials WHERE MaterialID=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public List<RawMaterial> getAllMaterials() {
        List<RawMaterial> list = new ArrayList<>();
        String sql = "SELECT rm.*, s.SupplierName FROM RawMaterials rm " +
                     "LEFT JOIN Suppliers s ON rm.SupplierID = s.SupplierID ORDER BY rm.MaterialID ASC";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<RawMaterial> getMaterialsBySupplier(int supplierID) {
        List<RawMaterial> list = new ArrayList<>();
        String sql = "SELECT rm.*, s.SupplierName FROM RawMaterials rm " +
                     "LEFT JOIN Suppliers s ON rm.SupplierID = s.SupplierID WHERE rm.SupplierID=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, supplierID);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<RawMaterial> searchMaterials(String kw) {
        List<RawMaterial> list = new ArrayList<>();
        String sql = "SELECT rm.*, s.SupplierName FROM RawMaterials rm " +
                     "LEFT JOIN Suppliers s ON rm.SupplierID = s.SupplierID " +
                     "WHERE rm.MaterialName LIKE ? OR rm.Unit LIKE ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String w = "%" + kw + "%";
            ps.setString(1, w); ps.setString(2, w);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // Called after a purchase is received — adds to StockQuantity
    public void updateStock(Connection con, int materialID, double qty) throws SQLException {
        String sql = "UPDATE RawMaterials SET StockQuantity = StockQuantity + ? WHERE MaterialID=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, qty);
            ps.setInt(2, materialID);
            ps.executeUpdate();
        }
    }

    private RawMaterial map(ResultSet rs) throws SQLException {
        return new RawMaterial(
            rs.getInt("MaterialID"),
            rs.getTimestamp("CreatedAt"),
            rs.getString("MaterialName"),
            rs.getDouble("StockQuantity"),
            rs.getString("Unit"),
            rs.getDouble("UnitPrice"),
            rs.getInt("SupplierID"),
            rs.getString("SupplierName")
        );
    }
}
