package com.textlite.model;

import java.util.Date;

public class RawMaterial {
    private int    materialID;
    private Date   createdAt;
    private String materialName;
    private double stockQuantity;
    private String unit;
    private double unitPrice;
    private int    supplierID;
    private String supplierName; // joined display

    public RawMaterial() {}

    public RawMaterial(int materialID, Date createdAt, String materialName,
                       double stockQuantity, String unit, double unitPrice,
                       int supplierID, String supplierName) {
        this.materialID    = materialID;
        this.createdAt     = createdAt;
        this.materialName  = materialName;
        this.stockQuantity = stockQuantity;
        this.unit          = unit;
        this.unitPrice     = unitPrice;
        this.supplierID    = supplierID;
        this.supplierName  = supplierName;
    }

    public int    getMaterialID()               { return materialID; }
    public void   setMaterialID(int v)          { this.materialID = v; }
    public Date   getCreatedAt()                { return createdAt; }
    public void   setCreatedAt(Date v)          { this.createdAt = v; }
    public String getMaterialName()             { return materialName; }
    public void   setMaterialName(String v)     { this.materialName = v; }
    public double getStockQuantity()            { return stockQuantity; }
    public void   setStockQuantity(double v)    { this.stockQuantity = v; }
    public String getUnit()                     { return unit; }
    public void   setUnit(String v)             { this.unit = v; }
    public double getUnitPrice()                { return unitPrice; }
    public void   setUnitPrice(double v)        { this.unitPrice = v; }
    public int    getSupplierID()               { return supplierID; }
    public void   setSupplierID(int v)          { this.supplierID = v; }
    public String getSupplierName()             { return supplierName; }
    public void   setSupplierName(String v)     { this.supplierName = v; }

    @Override
    public String toString() { return materialName; }
}
