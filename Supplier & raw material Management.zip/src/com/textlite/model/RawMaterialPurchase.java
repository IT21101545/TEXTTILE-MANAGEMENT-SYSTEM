package com.textlite.model;

import java.util.Date;

public class RawMaterialPurchase {
    private int    purchaseID;
    private String notes;
    private Date   purchaseDate;
    private double quantity;
    private double totalAmount;
    private int    materialID;
    private int    supplierID;
    // joined display fields
    private String materialName;
    private String supplierName;
    private String unit;

    public RawMaterialPurchase() {}

    public RawMaterialPurchase(int purchaseID, String notes, Date purchaseDate,
                               double quantity, double totalAmount,
                               int materialID, int supplierID,
                               String materialName, String supplierName, String unit) {
        this.purchaseID   = purchaseID;
        this.notes        = notes;
        this.purchaseDate = purchaseDate;
        this.quantity     = quantity;
        this.totalAmount  = totalAmount;
        this.materialID   = materialID;
        this.supplierID   = supplierID;
        this.materialName = materialName;
        this.supplierName = supplierName;
        this.unit         = unit;
    }

    public int    getPurchaseID()               { return purchaseID; }
    public void   setPurchaseID(int v)          { this.purchaseID = v; }
    public String getNotes()                    { return notes; }
    public void   setNotes(String v)            { this.notes = v; }
    public Date   getPurchaseDate()             { return purchaseDate; }
    public void   setPurchaseDate(Date v)       { this.purchaseDate = v; }
    public double getQuantity()                 { return quantity; }
    public void   setQuantity(double v)         { this.quantity = v; }
    public double getTotalAmount()              { return totalAmount; }
    public void   setTotalAmount(double v)      { this.totalAmount = v; }
    public int    getMaterialID()               { return materialID; }
    public void   setMaterialID(int v)          { this.materialID = v; }
    public int    getSupplierID()               { return supplierID; }
    public void   setSupplierID(int v)          { this.supplierID = v; }
    public String getMaterialName()             { return materialName; }
    public void   setMaterialName(String v)     { this.materialName = v; }
    public String getSupplierName()             { return supplierName; }
    public void   setSupplierName(String v)     { this.supplierName = v; }
    public String getUnit()                     { return unit; }
    public void   setUnit(String v)             { this.unit = v; }
}
