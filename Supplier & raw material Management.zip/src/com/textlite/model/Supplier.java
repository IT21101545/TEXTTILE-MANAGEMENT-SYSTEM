package com.textlite.model;

public class Supplier {
    private int supplierID;
    private String supplierName;
    private String phone;
    private String email;
    private String address;

    public Supplier() {}

    public Supplier(int supplierID, String supplierName, String phone, String email, String address) {
        this.supplierID   = supplierID;
        this.supplierName = supplierName;
        this.phone        = phone;
        this.email        = email;
        this.address      = address;
    }

    public int    getSupplierID()               { return supplierID; }
    public void   setSupplierID(int v)          { this.supplierID = v; }
    public String getSupplierName()             { return supplierName; }
    public void   setSupplierName(String v)     { this.supplierName = v; }
    public String getPhone()                    { return phone; }
    public void   setPhone(String v)            { this.phone = v; }
    public String getEmail()                    { return email; }
    public void   setEmail(String v)            { this.email = v; }
    public String getAddress()                  { return address; }
    public void   setAddress(String v)          { this.address = v; }

    @Override
    public String toString() { return supplierName; }
}
