package com.textlite.ui;

import javax.swing.*;
import java.awt.*;

public class FooterPanel extends JPanel {

    public FooterPanel() {
        setBackground(Theme.DARK_BG);
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(18, 30, 18, 30));

        // Top row: 3 columns
        JPanel topRow = new JPanel(new GridLayout(1, 3, 20, 0));
        topRow.setBackground(Theme.DARK_BG);

        // Brand column
        JPanel brandCol = new JPanel();
        brandCol.setLayout(new BoxLayout(brandCol, BoxLayout.Y_AXIS));
        brandCol.setBackground(Theme.DARK_BG);
        JLabel brandLbl = new JLabel("\uD83D\uDC55 ZEE FASHION");
        brandLbl.setFont(Theme.BRAND_FONT);
        brandLbl.setForeground(Theme.GOLD);
        JLabel brandDesc = new JLabel("<html><p style='width:160px;color:#aaa;font-size:11px;'>Your premier destination for high-quality fabrics.</p></html>");
        brandCol.add(brandLbl);
        brandCol.add(Box.createVerticalStrut(6));
        brandCol.add(brandDesc);

        // Customer Care column
        JPanel careCol = new JPanel();
        careCol.setLayout(new BoxLayout(careCol, BoxLayout.Y_AXIS));
        careCol.setBackground(Theme.DARK_BG);
        addFooterTitle(careCol, "Customer Care");
        addFooterLink(careCol, "Shipping & Delivery");
        addFooterLink(careCol, "Returns & Exchanges");
        addFooterLink(careCol, "Privacy Policy");
        addFooterLink(careCol, "Terms of Service");
        addFooterLink(careCol, "FAQ");

        // Contact column
        JPanel contactCol = new JPanel();
        contactCol.setLayout(new BoxLayout(contactCol, BoxLayout.Y_AXIS));
        contactCol.setBackground(Theme.DARK_BG);
        addFooterTitle(contactCol, "Contact Details");
        addFooterLink(contactCol, "\uD83C\uDFEA  Shop Name: ZEE FASHION");
        addFooterLink(contactCol, "\uD83D\uDC64  Client Name: M.Z Aathif");
        addFooterLink(contactCol, "\uD83D\uDCDE  Contact: 0777718414");
        addFooterLink(contactCol, "\u2709  Email: mohammedathif269@gmail.com");

        topRow.add(brandCol);
        topRow.add(careCol);
        topRow.add(contactCol);

        // Bottom bar
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomBar.setBackground(new Color(20, 20, 20));
        JLabel copy = new JLabel("© 2026 ZEE FASHION. All rights reserved.  |  Privacy Policy  |  Terms of Service");
        copy.setFont(Theme.SMALL_FONT);
        copy.setForeground(new Color(150, 150, 150));
        bottomBar.add(copy);

        add(topRow, BorderLayout.CENTER);
        add(bottomBar, BorderLayout.SOUTH);
    }

    private void addFooterTitle(JPanel panel, String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(Theme.WHITE);
        panel.add(lbl);
        panel.add(Box.createVerticalStrut(6));
    }

    private void addFooterLink(JPanel panel, String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(Theme.SMALL_FONT);
        lbl.setForeground(new Color(170, 170, 170));
        panel.add(lbl);
        panel.add(Box.createVerticalStrut(3));
    }
}
