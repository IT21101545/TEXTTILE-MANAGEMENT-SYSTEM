package com.textlite.ui;

import java.awt.*;

public class Theme {
    // ZEE FASHION color palette from the design
    public static final Color DARK_BG      = new Color(28, 28, 28);      // navbar/footer dark
    public static final Color GOLD         = new Color(184, 148, 74);     // ZEE FASHION gold
    public static final Color WHITE        = Color.WHITE;
    public static final Color LIGHT_BG     = new Color(245, 243, 238);    // page background cream
    public static final Color TABLE_HEADER = Color.BLACK;
    public static final Color TABLE_ROW1   = new Color(255, 255, 255);
    public static final Color TABLE_ROW2   = new Color(245, 243, 238);
    public static final Color BTN_ADD      = new Color(101, 67, 33);   // dark brown
    public static final Color BTN_EDIT     = new Color(139, 90, 43);   // medium brown
    public static final Color BTN_DELETE   = new Color(80, 40, 20);    // deep brown
    public static final Color BTN_CLEAR    = new Color(160, 120, 80);  // light brown
    public static final Color LOW_STOCK    = new Color(220, 53, 69);
    public static final Color OK_STOCK     = new Color(40, 167, 69);
    public static final Color PENDING_CLR  = new Color(255, 193, 7);
    public static final Color RECEIVED_CLR = new Color(40, 167, 69);
    public static final Color CANCELLED_CLR= new Color(220, 53, 69);

    public static final Font TITLE_FONT  = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font BODY_FONT   = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font SMALL_FONT  = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font BRAND_FONT  = new Font("Serif", Font.BOLD, 16);
}
