package com.textlite.ui;

import com.textlite.dao.SupplierDAO;
import com.textlite.model.Supplier;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.regex.Pattern;

public class SupplierPanel extends JPanel {

    private final SupplierDAO dao = new SupplierDAO();
    private JTextField txtName, txtPhone, txtEmail, txtAddress, txtSearch;
    private JLabel lblMsg;
    private JTable table;
    private DefaultTableModel tableModel;
    private int selectedID = -1;

    public SupplierPanel(MainFrame mainFrame) {
        setBackground(Theme.LIGHT_BG);
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Theme.LIGHT_BG);
        JLabel title = new JLabel("Supplier Management");
        title.setFont(Theme.TITLE_FONT);
        title.setForeground(Theme.DARK_BG);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        right.setBackground(Theme.LIGHT_BG);
        txtSearch = new JTextField(18); txtSearch.setFont(Theme.BODY_FONT);
        JButton btnS = btn("Search",   Theme.DARK_BG,   Theme.WHITE);
        JButton btnA = btn("Show All", Theme.BTN_CLEAR, Theme.WHITE);
        btnS.addActionListener(e -> doSearch());
        btnA.addActionListener(e -> loadData());
        right.add(new JLabel("Search: ")); right.add(txtSearch);
        right.add(btnS); right.add(btnA);

        p.add(title, BorderLayout.WEST);
        p.add(right,  BorderLayout.EAST);
        return p;
    }

    private JPanel buildCenter() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(Theme.LIGHT_BG);
        p.add(buildForm(),  BorderLayout.NORTH);
        p.add(buildTable(), BorderLayout.CENTER);
        return p;
    }

    private JPanel buildForm() {
        JPanel card = card();
        JLabel title = new JLabel("Supplier Details");
        title.setFont(Theme.HEADER_FONT); title.setForeground(Theme.DARK_BG);

        JPanel fields = new JPanel(new GridLayout(2, 4, 10, 8));
        fields.setBackground(Theme.WHITE);
        txtName    = tf(); txtPhone = tf(); txtEmail = tf(); txtAddress = tf();
        fields.add(lbl("Supplier Name *")); fields.add(txtName);
        fields.add(lbl("Phone *"));         fields.add(txtPhone);
        fields.add(lbl("Email *"));         fields.add(txtEmail);
        fields.add(lbl("Address"));         fields.add(txtAddress);

        lblMsg = new JLabel(" ");
        lblMsg.setFont(Theme.SMALL_FONT);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        btnRow.setBackground(Theme.WHITE);
        JButton bAdd = btn("Add",    Theme.BTN_ADD,    Theme.WHITE);
        JButton bUpd = btn("Update", Theme.BTN_EDIT,   Theme.WHITE);
        JButton bDel = btn("Delete", Theme.BTN_DELETE, Theme.WHITE);
        JButton bClr = btn("Clear",  Theme.BTN_CLEAR,  Theme.WHITE);
        bAdd.addActionListener(e -> doAdd());
        bUpd.addActionListener(e -> doUpdate());
        bDel.addActionListener(e -> doDelete());
        bClr.addActionListener(e -> clearForm());
        btnRow.add(bAdd); btnRow.add(bUpd); btnRow.add(bDel); btnRow.add(bClr);

        card.add(title,  BorderLayout.NORTH);
        card.add(fields, BorderLayout.CENTER);
        JPanel s = new JPanel(new BorderLayout()); s.setBackground(Theme.WHITE);
        s.add(lblMsg, BorderLayout.NORTH); s.add(btnRow, BorderLayout.CENTER);
        card.add(s, BorderLayout.SOUTH);
        return card;
    }

    private JScrollPane buildTable() {
        String[] cols = {"ID", "Supplier Name", "Phone", "Email", "Address"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(180);
        table.getColumnModel().getColumn(2).setPreferredWidth(110);
        table.getColumnModel().getColumn(3).setPreferredWidth(180);
        table.getColumnModel().getColumn(4).setPreferredWidth(200);
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) fillForm(); });
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));
        return sp;
    }

    // ---- CRUD ----
    private void doAdd() {
        if (!validateForm()) return;
        if (dao.addSupplier(build())) { ok("Supplier added."); clearForm(); loadData(); }
        else err("Failed to add supplier.");
    }

    private void doUpdate() {
        if (selectedID == -1) { err("Select a supplier to update."); return; }
        if (!validateForm()) return;
        Supplier s = build(); s.setSupplierID(selectedID);
        if (dao.updateSupplier(s)) { ok("Supplier updated."); clearForm(); loadData(); }
        else err("Failed to update.");
    }

    private void doDelete() {
        if (selectedID == -1) { err("Select a supplier to delete."); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete this supplier?", "Confirm",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
            if (dao.deleteSupplier(selectedID)) { ok("Deleted."); clearForm(); loadData(); }
            else err("Cannot delete — supplier has linked records.");
        }
    }

    private void doSearch() {
        String kw = txtSearch.getText().trim();
        if (kw.isEmpty()) { loadData(); return; }
        populateTable(dao.searchSuppliers(kw));
    }

    // ---- Validation ----
    private boolean validateForm() {
        String name  = txtName.getText().trim();
        String phone = txtPhone.getText().trim();
        String email = txtEmail.getText().trim();
        if (name.isEmpty())  { err("Supplier Name is required."); txtName.requestFocus(); return false; }
        if (name.length()<2) { err("Name must be at least 2 characters."); return false; }
        if (phone.isEmpty()) { err("Phone is required."); txtPhone.requestFocus(); return false; }
        if (!phone.matches("^[0-9]{10}$")) { err("Phone must be exactly 10 digits."); return false; }
        if (email.isEmpty()) { err("Email is required."); txtEmail.requestFocus(); return false; }
        if (!Pattern.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$", email)) {
            err("Enter a valid email."); return false;
        }
        lblMsg.setText(" "); return true;
    }

    // ---- Helpers ----
    public void loadData() { populateTable(dao.getAllSuppliers()); }

    private void populateTable(List<Supplier> list) {
        tableModel.setRowCount(0);
        for (Supplier s : list)
            tableModel.addRow(new Object[]{ s.getSupplierID(), s.getSupplierName(), s.getPhone(), s.getEmail(), s.getAddress() });
    }

    private void fillForm() {
        int row = table.getSelectedRow(); if (row == -1) return;
        selectedID = (int) tableModel.getValueAt(row, 0);
        txtName.setText((String) tableModel.getValueAt(row, 1));
        txtPhone.setText((String) tableModel.getValueAt(row, 2));
        txtEmail.setText((String) tableModel.getValueAt(row, 3));
        txtAddress.setText((String) tableModel.getValueAt(row, 4));
        lblMsg.setText(" ");
    }

    private Supplier build() {
        Supplier s = new Supplier();
        s.setSupplierName(txtName.getText().trim());
        s.setPhone(txtPhone.getText().trim());
        s.setEmail(txtEmail.getText().trim());
        s.setAddress(txtAddress.getText().trim());
        return s;
    }

    private void clearForm() {
        selectedID = -1;
        txtName.setText(""); txtPhone.setText(""); txtEmail.setText(""); txtAddress.setText("");
        lblMsg.setText(" "); table.clearSelection();
    }

    private void err(String m) { lblMsg.setForeground(Theme.BTN_DELETE); lblMsg.setText(m); }
    private void ok(String m)  { lblMsg.setForeground(Theme.OK_STOCK);   lblMsg.setText(m); }

    // ---- Style ----
    private JPanel card() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBackground(Theme.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220,220,220)),
            BorderFactory.createEmptyBorder(14,16,14,16)));
        return p;
    }
    private JLabel lbl(String t) { JLabel l = new JLabel(t); l.setFont(Theme.BODY_FONT); l.setForeground(Theme.DARK_BG); return l; }
    private JTextField tf() {
        JTextField f = new JTextField(); f.setFont(Theme.BODY_FONT);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200,200,200)),
            BorderFactory.createEmptyBorder(4,6,4,6)));
        return f;
    }
    private JButton btn(String t, Color bg, Color fg) {
        JButton b = new JButton(t); b.setFont(Theme.BODY_FONT); b.setBackground(bg); b.setForeground(fg);
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(7,14,7,14)); return b;
    }
    private void styleTable(JTable t) {
        t.setFont(Theme.BODY_FONT); t.setRowHeight(28);
        t.setGridColor(new Color(230,230,230));
        t.setSelectionBackground(new Color(184,148,74,80));
        t.setSelectionForeground(Theme.DARK_BG);
        t.setShowHorizontalLines(true); t.setShowVerticalLines(false);
        JTableHeader h = t.getTableHeader();
        h.setBackground(Theme.TABLE_HEADER); h.setForeground(Theme.WHITE);
        h.setFont(Theme.HEADER_FONT); h.setReorderingAllowed(false);
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tbl, Object val, boolean sel, boolean foc, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(tbl, val, sel, foc, r, c);
                lbl.setBackground(Color.BLACK);
                lbl.setForeground(Color.WHITE);
                lbl.setFont(Theme.HEADER_FONT);
                lbl.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                lbl.setOpaque(true);
                return lbl;
            }
        });
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tbl, Object val, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tbl, val, sel, foc, r, c);
                if (!sel) setBackground(r%2==0 ? Theme.TABLE_ROW1 : Theme.TABLE_ROW2);
                setBorder(BorderFactory.createEmptyBorder(0,8,0,8)); return this;
            }
        });
    }
}
