package com.textlite.ui;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private CardLayout cardLayout;
    private JPanel contentPanel;

    private SupplierPanel supplierPanel;
    private RawMaterialPanel rawMaterialPanel;
    private PurchaseHistoryPanel purchaseHistoryPanel;

    public MainFrame() {
        setTitle("ZEE FASHION - Supplier & Raw Material Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setMinimumSize(new Dimension(1000, 700));
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        // Navbar
        add(new NavbarPanel(this), BorderLayout.NORTH);

        // Content (CardLayout)
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(Theme.LIGHT_BG);

        supplierPanel        = new SupplierPanel(this);
        rawMaterialPanel     = new RawMaterialPanel(this);
        purchaseHistoryPanel = new PurchaseHistoryPanel(this);

        contentPanel.add(supplierPanel,        "SUPPLIER");
        contentPanel.add(rawMaterialPanel,     "RAWMATERIAL");
        contentPanel.add(purchaseHistoryPanel, "PURCHASE");

        add(contentPanel, BorderLayout.CENTER);

        // Footer
        add(new FooterPanel(), BorderLayout.SOUTH);

        showPanel("SUPPLIER");
        setVisible(true);
    }

    public void showPanel(String name) {
        cardLayout.show(contentPanel, name);
        // Refresh data when switching panels
        switch (name) {
            case "SUPPLIER":        supplierPanel.loadData(); break;
            case "RAWMATERIAL":     rawMaterialPanel.loadData(); break;
            case "PURCHASE":        purchaseHistoryPanel.loadData(); break;
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(MainFrame::new);
    }
}
