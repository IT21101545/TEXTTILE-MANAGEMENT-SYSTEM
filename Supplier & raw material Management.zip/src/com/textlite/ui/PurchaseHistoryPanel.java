package com.textlite.ui;

import com.textlite.dao.RawMaterialDAO;
import com.textlite.dao.RawMaterialPurchaseDAO;
import com.textlite.dao.SupplierDAO;
import com.textlite.model.RawMaterial;
import com.textlite.model.RawMaterialPurchase;
import com.textlite.model.Supplier;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class PurchaseHistoryPanel extends JPanel {

    private final RawMaterialPurchaseDAO dao    = new RawMaterialPurchaseDAO();
    private final SupplierDAO            supDAO = new SupplierDAO();
    private final RawMaterialDAO         matDAO = new RawMaterialDAO();

    private JComboBox<Supplier>     cmbSupplier;
    private JComboBox<RawMaterial>  cmbMaterial;
    private JTextField txtQty, txtTotal, txtDate, txtNotes, txtSearch;
    private JLabel lblMsg;
    private JTable table;
    private DefaultTableModel tableModel;
    private int selectedID = -1;

    public PurchaseHistoryPanel(MainFrame mainFrame) {
        setBackground(Theme.LIGHT_BG);
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Theme.LIGHT_BG);
        JLabel title = new JLabel("Raw Material Purchases");
        title.setFont(Theme.TITLE_FONT); title.setForeground(Theme.DARK_BG);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        right.setBackground(Theme.LIGHT_BG);
        txtSearch = new JTextField(18); txtSearch.setFont(Theme.BODY_FONT);
        JButton btnS = btn("Search",   Theme.DARK_BG,   Theme.WHITE);
        JButton btnA = btn("Show All", Theme.BTN_CLEAR, Theme.WHITE);
        btnS.addActionListener(e -> doSearch());
        btnA.addActionListener(e -> loadData());
        right.add(new JLabel("Search: ")); right.add(txtSearch);
        right.add(btnS); right.add(btnA);

        p.add(title, BorderLayout.WEST);
        p.add(right,  BorderLayout.EAST);
        return p;
    }

    private JPanel buildCenter() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(Theme.LIGHT_BG);
        p.add(buildForm(),  BorderLayout.NORTH);
        p.add(buildTable(), BorderLayout.CENTER);
        return p;
    }

    private JPanel buildForm() {
        JPanel card = card();
        JLabel title = new JLabel("Purchase Details");
        title.setFont(Theme.HEADER_FONT); title.setForeground(Theme.DARK_BG);

        JPanel fields = new JPanel(new GridLayout(3, 4, 10, 8));
        fields.setBackground(Theme.WHITE);

        cmbSupplier = new JComboBox<>(); cmbSupplier.setFont(Theme.BODY_FONT);
        cmbMaterial = new JComboBox<>(); cmbMaterial.setFont(Theme.BODY_FONT);
        txtQty   = tf(); txtTotal = tf(); txtTotal.setEditable(false);
        txtTotal.setBackground(new Color(240,240,240));
        txtDate  = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date())); styleField(txtDate);
        txtNotes = tf();

        // When supplier changes → filter materials
        cmbSupplier.addActionListener(e -> filterMaterials());
        // When material or qty changes → auto-calc total
        cmbMaterial.addActionListener(e -> calcTotal());
        txtQty.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { calcTotal(); }
        });

        fields.add(lbl("Supplier *"));        fields.add(cmbSupplier);
        fields.add(lbl("Raw Material *"));    fields.add(cmbMaterial);
        fields.add(lbl("Quantity *"));         fields.add(txtQty);
        fields.add(lbl("Total Amount (Rs.)")); fields.add(txtTotal);
        fields.add(lbl("Purchase Date *"));    fields.add(txtDate);
        fields.add(lbl("Notes"));              fields.add(txtNotes);

        lblMsg = new JLabel(" "); lblMsg.setFont(Theme.SMALL_FONT);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        btnRow.setBackground(Theme.WHITE);
        JButton bAdd = btn("Add Purchase", Theme.BTN_ADD,    Theme.WHITE);
        JButton bUpd = btn("Update",       Theme.BTN_EDIT,   Theme.WHITE);
        JButton bDel = btn("Delete",       Theme.BTN_DELETE, Theme.WHITE);
        JButton bClr = btn("Clear",        Theme.BTN_CLEAR,  Theme.WHITE);
        bAdd.addActionListener(e -> doAdd());
        bUpd.addActionListener(e -> doUpdate());
        bDel.addActionListener(e -> doDelete());
        bClr.addActionListener(e -> clearForm());
        btnRow.add(bAdd); btnRow.add(bUpd); btnRow.add(bDel); btnRow.add(bClr);

        card.add(title,  BorderLayout.NORTH);
        card.add(fields, BorderLayout.CENTER);
        JPanel s = new JPanel(new BorderLayout()); s.setBackground(Theme.WHITE);
        s.add(lblMsg, BorderLayout.NORTH); s.add(btnRow, BorderLayout.CENTER);
        card.add(s, BorderLayout.SOUTH);
        return card;
    }

    private JScrollPane buildTable() {
        String[] cols = {"ID", "Supplier", "Material", "Qty", "Unit", "Total (Rs.)", "Purchase Date", "Notes"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        styleTable(table);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        table.getColumnModel().getColumn(2).setPreferredWidth(150);
        table.getColumnModel().getColumn(3).setPreferredWidth(70);
        table.getColumnModel().getColumn(4).setPreferredWidth(70);
        table.getColumnModel().getColumn(5).setPreferredWidth(110);
        table.getColumnModel().getColumn(6).setPreferredWidth(100);
        table.getColumnModel().getColumn(7).setPreferredWidth(180);
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) fillForm(); });
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));
        return sp;
    }

    // ---- CRUD ----
    private void doAdd() {
        if (!validateForm()) return;
        RawMaterialPurchase p = build();
        if (dao.addPurchase(p)) {
            ok("Purchase added. Stock updated automatically.");
            clearForm(); loadData();
        } else err("Failed to add purchase.");
    }

    private void doUpdate() {
        if (selectedID == -1) { err("Select a purchase to update."); return; }
        if (!validateForm()) return;
        RawMaterialPurchase p = build(); p.setPurchaseID(selectedID);
        if (dao.updatePurchase(p)) { ok("Purchase updated."); clearForm(); loadData(); }
        else err("Failed to update.");
    }

    private void doDelete() {
        if (selectedID == -1) { err("Select a purchase to delete."); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete this purchase record?", "Confirm",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
            if (dao.deletePurchase(selectedID)) { ok("Deleted."); clearForm(); loadData(); }
            else err("Failed to delete.");
        }
    }

    private void doSearch() {
        String kw = txtSearch.getText().trim();
        if (kw.isEmpty()) { loadData(); return; }
        populateTable(dao.searchPurchases(kw));
    }

    // ---- Validation ----
    private boolean validateForm() {
        if (cmbSupplier.getSelectedItem() == null) { err("Select a supplier."); return false; }
        if (cmbMaterial.getSelectedItem() == null) { err("Select a raw material."); return false; }
        String qty  = txtQty.getText().trim();
        String date = txtDate.getText().trim();
        if (qty.isEmpty()) { err("Quantity is required."); txtQty.requestFocus(); return false; }
        try { if (Double.parseDouble(qty) <= 0) { err("Quantity must be > 0."); return false; } }
        catch (NumberFormatException e) { err("Quantity must be a number."); return false; }
        if (date.isEmpty()) { err("Purchase Date is required."); return false; }
        try { new SimpleDateFormat("yyyy-MM-dd").parse(date); }
        catch (Exception e) { err("Date format: yyyy-MM-dd (e.g. 2026-03-25)"); return false; }
        lblMsg.setText(" "); return true;
    }

    // ---- Helpers ----
    public void loadData() {
        loadSuppliers();
        populateTable(dao.getAllPurchases());
    }

    private void loadSuppliers() {
        cmbSupplier.removeAllItems();
        for (Supplier s : supDAO.getAllSuppliers()) cmbSupplier.addItem(s);
        filterMaterials();
    }

    private void filterMaterials() {
        cmbMaterial.removeAllItems();
        Supplier sup = (Supplier) cmbSupplier.getSelectedItem();
        if (sup == null) return;
        for (RawMaterial m : matDAO.getMaterialsBySupplier(sup.getSupplierID()))
            cmbMaterial.addItem(m);
    }

    private void calcTotal() {
        try {
            RawMaterial m = (RawMaterial) cmbMaterial.getSelectedItem();
            double qty = Double.parseDouble(txtQty.getText().trim());
            if (m != null) txtTotal.setText(String.format("%.2f", qty * m.getUnitPrice()));
        } catch (NumberFormatException e) { txtTotal.setText(""); }
    }

    private void populateTable(List<RawMaterialPurchase> list) {
        tableModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        for (RawMaterialPurchase p : list)
            tableModel.addRow(new Object[]{
                p.getPurchaseID(), p.getSupplierName(), p.getMaterialName(),
                String.format("%.2f", p.getQuantity()), p.getUnit(),
                String.format("Rs. %.2f", p.getTotalAmount()),
                p.getPurchaseDate() != null ? sdf.format(p.getPurchaseDate()) : "",
                p.getNotes()
            });
    }

    private void fillForm() {
        int row = table.getSelectedRow(); if (row == -1) return;
        selectedID = (int) tableModel.getValueAt(row, 0);
        // Select supplier
        String supName = (String) tableModel.getValueAt(row, 1);
        for (int i = 0; i < cmbSupplier.getItemCount(); i++) {
            if (cmbSupplier.getItemAt(i).getSupplierName().equals(supName)) {
                cmbSupplier.setSelectedIndex(i); break;
            }
        }
        // Select material
        String matName = (String) tableModel.getValueAt(row, 2);
        for (int i = 0; i < cmbMaterial.getItemCount(); i++) {
            RawMaterial rm = cmbMaterial.getItemAt(i);
            if (rm != null && rm.getMaterialName().equals(matName)) {
                cmbMaterial.setSelectedIndex(i); break;
            }
        }
        txtQty.setText(tableModel.getValueAt(row, 3).toString());
        txtDate.setText(tableModel.getValueAt(row, 6).toString());
        txtNotes.setText(tableModel.getValueAt(row, 7) != null ? tableModel.getValueAt(row, 7).toString() : "");
        calcTotal();
        lblMsg.setText(" ");
    }

    private RawMaterialPurchase build() {
        RawMaterialPurchase p = new RawMaterialPurchase();
        Supplier sup = (Supplier) cmbSupplier.getSelectedItem();
        RawMaterial mat = (RawMaterial) cmbMaterial.getSelectedItem();
        p.setSupplierID(sup.getSupplierID());
        p.setMaterialID(mat.getMaterialID());
        double qty = Double.parseDouble(txtQty.getText().trim());
        p.setQuantity(qty);
        p.setTotalAmount(qty * mat.getUnitPrice());
        p.setUnit(mat.getUnit());
        try { p.setPurchaseDate(new SimpleDateFormat("yyyy-MM-dd").parse(txtDate.getText().trim())); }
        catch (Exception e) { p.setPurchaseDate(new Date()); }
        p.setNotes(txtNotes.getText().trim());
        return p;
    }

    private void clearForm() {
        selectedID = -1;
        txtQty.setText(""); txtTotal.setText(""); txtNotes.setText("");
        txtDate.setText(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        lblMsg.setText(" "); table.clearSelection();
    }

    private void err(String m) { lblMsg.setForeground(Theme.BTN_DELETE); lblMsg.setText(m); }
    private void ok(String m)  { lblMsg.setForeground(Theme.OK_STOCK);   lblMsg.setText(m); }

    // ---- Style ----
    private JPanel card() {
        JPanel p = new JPanel(new BorderLayout(8,8)); p.setBackground(Theme.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220,220,220)),
            BorderFactory.createEmptyBorder(14,16,14,16))); return p;
    }
    private JLabel lbl(String t) { JLabel l = new JLabel(t); l.setFont(Theme.BODY_FONT); l.setForeground(Theme.DARK_BG); return l; }
    private JTextField tf() {
        JTextField f = new JTextField(); f.setFont(Theme.BODY_FONT);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200,200,200)),
            BorderFactory.createEmptyBorder(4,6,4,6))); return f;
    }
    private void styleField(JTextField f) {
        f.setFont(Theme.BODY_FONT);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200,200,200)),
            BorderFactory.createEmptyBorder(4,6,4,6)));
    }
    private JButton btn(String t, Color bg, Color fg) {
        JButton b = new JButton(t); b.setFont(Theme.BODY_FONT); b.setBackground(bg); b.setForeground(fg);
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(7,14,7,14)); return b;
    }
    private void styleTable(JTable t) {
        t.setFont(Theme.BODY_FONT); t.setRowHeight(28);
        t.setGridColor(new Color(230,230,230));
        t.setSelectionBackground(new Color(184,148,74,80));
        t.setSelectionForeground(Theme.DARK_BG);
        t.setShowHorizontalLines(true); t.setShowVerticalLines(false);
        JTableHeader h = t.getTableHeader();
        h.setBackground(Theme.TABLE_HEADER); h.setForeground(Theme.WHITE);
        h.setFont(Theme.HEADER_FONT); h.setReorderingAllowed(false);
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tbl, Object val, boolean sel, boolean foc, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(tbl, val, sel, foc, r, c);
                lbl.setBackground(Color.BLACK);
                lbl.setForeground(Color.WHITE);
                lbl.setFont(Theme.HEADER_FONT);
                lbl.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                lbl.setOpaque(true);
                return lbl;
            }
        });
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tbl, Object val, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tbl, val, sel, foc, r, c);
                if (!sel) setBackground(r%2==0 ? Theme.TABLE_ROW1 : Theme.TABLE_ROW2);
                setBorder(BorderFactory.createEmptyBorder(0,8,0,8)); return this;
            }
        });
    }
}
