package com.textlite.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class NavbarPanel extends JPanel {

    private MainFrame mainFrame;

    public NavbarPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setBackground(Theme.DARK_BG);
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
        setPreferredSize(new Dimension(0, 55));

        // Brand
        JLabel brand = new JLabel("\uD83D\uDC55 ZEE FASHION");
        brand.setFont(Theme.BRAND_FONT);
        brand.setForeground(Theme.GOLD);

        // Nav buttons
        JPanel navLinks = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        navLinks.setBackground(Theme.DARK_BG);
        navLinks.add(createNavBtn("Suppliers", e -> mainFrame.showPanel("SUPPLIER")));
        navLinks.add(createNavBtn("Raw Materials", e -> mainFrame.showPanel("RAWMATERIAL")));
        navLinks.add(createNavBtn("Purchase History", e -> mainFrame.showPanel("PURCHASE")));

        add(brand, BorderLayout.WEST);
        add(navLinks, BorderLayout.EAST);
    }

    private JButton createNavBtn(String text, ActionListener al) {
        JButton btn = new JButton(text);
        btn.setFont(Theme.BODY_FONT);
        btn.setForeground(Theme.WHITE);
        btn.setBackground(Theme.DARK_BG);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(al);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setForeground(Theme.GOLD); }
            public void mouseExited(MouseEvent e)  { btn.setForeground(Theme.WHITE); }
        });
        return btn;
    }
}
