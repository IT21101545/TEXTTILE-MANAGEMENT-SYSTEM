package com.textlite.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL =
        "jdbc:sqlserver://localhost:1433;databaseName=TextileManagementSystem;user=textlite_user;password=Textlite@2026;trustServerCertificate=true;encrypt=false;";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }
}
